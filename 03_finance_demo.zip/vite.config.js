import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueDevTools from 'vite-plugin-vue-devtools'
import AutoImport from 'unplugin-auto-import/vite';
import Components from 'unplugin-vue-components/vite';
import { VantResolver } from '@vant/auto-import-resolver';
import pxToViewport from 'postcss-px-to-viewport';


// https://vite.dev/config/
export default defineConfig({
  plugins: [
    vue(),
    vueDevTools(),
    AutoImport({
      resolvers: [VantResolver()],
    }),
    Components({
      resolvers: [VantResolver()],
    }),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    },
  },
  css: {
    postcss: {
      plugins: [
        pxToViewport({
          unitToConvert:'px',
          viewportWidth: 375,  // 视口宽度
          viewportHeight: 667, // 视口高度（可选）
          unitPrecision: 5,    // 转换后的 px 值的小数位数（默认为 5）
          viewportUnit: 'vw', // 希望使用的视口单位（vw/vh/vmin/vmax）
          selectorBlackList: ['.ignore-', 'ignore-'], // 指定不转换为视口单位的类名前缀
          minPixelValue: 1,   // 最小 px 转换阈值（小于或等于1px 不转换）
          mediaQuery: false,   // 允许在媒体查询中转换 px
          exclude: /node_modules/
        })
      ]
    }
  }
})
