import { createRouter,createWebHashHistory } from "vue-router";


const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    {
        path: '/',
        redirect: '/main'
    },
    {
        path: '/main',
        name: "main",
        component: () => import("@/views/main/index.vue"),
        // meta: { keeAlive: true }
    },
//     {
//         path: '/home',
//         name: "home",
//         component: () => import("@/views/home/index.vue")
//     },
//     {
//         path: '/user',
//         name: "user",
//         component: () => import("@/views/user/index.vue")
//     }
  ]
})

export default router