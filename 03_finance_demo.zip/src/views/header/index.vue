<template>
  <div class=“home”>
    <div class="wrapper top">
      <div class="top-left">
        <!-- <img src="@/assets/img/logo.png" alt="招商银行"> -->
         <h1 class="title">
          <a href="#">招商银行</a>
         </h1>
      </div>
      <div class="top-right">
        <span class="right-home">
          <a href="#">home</a>
        </span>
        <span class="right-list">
          <a href="#">list</a>
        </span>
      </div>
    </div>
  </div>
</template>


<script setup>


</script>


<style lang="less" scoped>
@import "@/assets/css/index.css";
.top {
  display: flex;
  justify-content: space-between;
  height: 62.39px;
  line-height: 62.39px;
  // background-color: blue;

  .top-left {
    .title{
      background-image: url(@/assets/img/logo.png);
      background-position:50%;
      background-repeat: no-repeat;
      background-size: contain;
      a {
        display: block;
        width: 114.39px;
        text-indent: -9999px;
      }
    }
  }

  .top-right {
    
    .right-home{
      background-image: url(@/assets/img/right-list.png);
      background-position:50%;
      background-repeat: no-repeat;
      background-size: contain;
      margin-right: 8px;

      a {
        display: inline-block;
        width: 20.8px;
        text-indent: -9999px;
      }
    }
    .right-list{
      background-image: url(@/assets/img/right-home.png);
      background-position:50%;
      background-repeat: no-repeat;
      background-size: contain;

      a {
        display: inline-block;
        width: 20.8px;
        text-indent: -9999px;
      }
    }

    
   

  }
}
</style>

