<template>
  <div class=“app”>
    <home-header></home-header>
    <content></content>
    <home-footer></home-footer>
    <!-- <router-view></router-view> -->
  </div>
</template>

<script>
  export default {
    name:"main"
  }
</script>

<script setup>
import HomeHeader from "@/views/header/index.vue"
import Content from "@/views/content/index.vue"
import HomeFooter from "@/views/footer/index.vue"

</script>


<style lang="less" scoped>


</style>

