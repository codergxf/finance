<template>
  <div class=“content”>
    <wipper></wipper>
    <home></home>
    <finance-message></finance-message>
    <service></service>
    <notice></notice>
    <news></news>
    <product></product>
  </div>
</template>


<script setup>
import Wipper from "@/views/content/cpns/wipper/index.vue"
import Home from "@/views/content/cpns/home/index.vue"
import FinanceMessage from "@/views/content/cpns/financemessage/index.vue"
import Service from "@/views/content/cpns/service/index.vue"
import Notice from "@/views/content/cpns/notice/index.vue"
import News from "@/views/content/cpns/news/index.vue"
import Product from "@/views/content/cpns/product/index.vue"
</script>


<style lang="less" scoped>
</style>

