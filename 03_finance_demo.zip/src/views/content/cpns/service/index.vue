<template>
  <div class=“service”>
    <div class="content">
      <div class="wrapper">
        <!-- 标题 -->
        <div class="title">
          <div class="titleinfo">实时金融信息</div>
          <div class="boder"></div>
        </div>

        <div class="picture">
          <div class="left">
            <div class="text">营业网点</div>
          </div>
          <div class="right">
            <div class="right-top">
              <div class="text">自助银行</div>
            </div>
            <div class="right-bottom">
              <div class="text">ATM查询</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script setup>


</script>


<style lang="less" scoped>

.content {
  
  .wrapper{
    width:335.91px;
    height: 218.36px;
    // background-color: aqua;
    margin: 0 auto 26px;
    
    .title{
      
      height: 33.25px;
      margin-right: 8.32px;
      padding-left: 10px;
      
      .titleinfo{
        font-family: PingFang SC;
        font-size: 12.48px;
        font-weight: 700;
      }
      .boder{
        background-color: #a30030;
        border-radius: 31.2px;
        bottom:-7.28px;
        height: 4.16px;
        width: 28.08px;
        margin-top: 5px;

        
        
      }
    }

    .picture {
      width:335.91px;
      // height: 185.11px;background-color: antiquewhite;
      display: flex;
      flex-wrap: wrap;

      
      .left {
        position: relative;
        width: 148.72px;
        height: 185.11px;
        background-image: url(@/assets/img/营业网点.png);
        background-position: 50%;
        background-repeat: no-repeat;
        background-size: cover;
        border-radius: 4.16px;
        box-shadow: 0 3.12px 6.24px rgba(0, 0, 0, .16);
        .text{
          font-size:12.48px ;
          color: #fff;
          font-family: PingFang SC;
          font-weight: 700;
          height: 16.64px;
          line-height: 16.64px;
          position: absolute;
          right: 10px;
          bottom: 5px;
          text-shadow: 0 1.04px 1.04px rgba(0, 0, 0, .46);
      }
      }
       .right{
        
        .right-top {
          position: relative;
          width: 177.42px;
          height: 55.11px;
          background-image: url(@/assets/img/自主银行.png);
          background-position: 50%;
          background-repeat: no-repeat;
          background-size: cover;
          border-radius: 4.16px;
          box-shadow: 0 3.12px 6.24px rgba(0, 0, 0, .16);
          margin-left: 8.5px;
          .text{
            font-size:12.48px ;
            color: #fff;
            font-family: PingFang SC;
            font-weight: 700;
            height: 16.64px;
            line-height: 16.64px;
            position: absolute;
            right: 10px;
            bottom: 5px;
            text-shadow: 0 1.04px 1.04px rgba(0, 0, 0, .46);
          }
        }

        .right-bottom{
          position: relative;
          width: 177.72px;
          height: 119.59px;
          background-image: url(@/assets/img/atm查询.png);
          background-position: 50%;
          background-repeat: no-repeat;
          background-size: cover;
          border-radius: 4.16px;
          box-shadow: 0 3.12px 6.24px rgba(0, 0, 0, .16);
          margin: 12px  0 0 9px;

          .text{
            font-size:12.48px ;
            color: #fff;
            font-family: PingFang SC;
            font-weight: 700;
            height: 16.64px;
            line-height: 16.64px;
            position: absolute;
            right: 10px;
            bottom: 5px;
            text-shadow: 0 1.04px 1.04px rgba(0, 0, 0, .46);
          }
        }
      }
    }
  }
}
</style>

