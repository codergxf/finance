<template>
  <div class=“financemessage”>
    <div class="content">
      <div class="wrapper">
        <div class="title">
          <div class="titleinfo">实时金融信息</div>
          <div class="boder"></div>
        </div>
        <div class="listcontent">
          <div class="list" v-for="item in messages" :key="item">
            <div class="dot"></div>
            <div class="text">{{ item }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script setup>
const messages=["存款利率","贷款利率","外汇实时汇率","黄金市场行情","个人理财产品净值","公司理财产品净值","离岸业务存款利率","国债柜台交易报价","招商股价","储蓄国债"]

</script>


<style lang="less" scoped>
.content {
  
  .wrapper{
    width:335.91px;
    height: 166.28px;
    // background-color: aqua;
    margin: 0 auto 26px;
    
    .title{
      
      height: 33.25px;
      margin-right: 8.32px;
      padding-left: 10px;
      
      .titleinfo{
        font-family: PingFang SC;
        font-size: 12.48px;
        font-weight: 700;
      }
      .boder{
        background-color: #a30030;
        border-radius: 31.2px;
        bottom:-7.28px;
        height: 4.16px;
        width: 28.08px;
        margin-top: 5px;

        
        
      }
    }

    .listcontent {
      display: flex;
      flex-wrap: wrap;
      width: 335.91px;
      height: 133.03px;
      background-color: #fff;
      border-radius: 15px;
      box-shadow: 3px 3px 8px  rgb(161, 161, 161);
     
      padding: 6.24px 24px;
      box-sizing: border-box;

      .list{
        position: relative;
        display: flex;
        justify-content: flex-start;
        width: 143.52px;
        height: 16.63px;
        margin-bottom: 9.32px;

        .dot{
          position: absolute;
          display: block;
          background-color: black;
          width: 3px;
          height: 3px;
          border-radius: 50%;
          top:5px;
          left:-5px;

          
        }

        .text {
          font-size: 12.48px;
        }
      }
    }
  }

}
</style>

