<template>
  <div class=“news”>
    <div class="content">
      <div class="wrapper">
        <div class="title">
          <div class="titleinfo">
            <a href="#">最新公告</a>
          </div>
          <div class="boder"></div>
        </div>
        <div class="picture">
          <div class="img"></div>
          <div class="listcontent">
            <div class="list" v-for="item in messages" :key="item">
              <div class="dot"></div>
              <div class="text">
                <a href="#">{{ item }}</a>
              </div>
            </div>
          <div class="more">更多</div>  
        </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script setup>
// import FinanceMessage from "@/components/titlemodule.vue"
const messages = ["关于调整人民币存款利率的公告","关于调整黄金账户认购起点金额及风险提示的通告"]
</script>


<style lang="less" scoped>
.content {
  
  .wrapper{
    width:335.91px;
    height: 190.22px;
    // background-color: aqua;
    margin: 0 auto 26px;
    
    .title{
      
      height: 33.25px;
      margin-right: 8.32px;
      padding-left: 10px;
      
      .titleinfo{
        font-family: PingFang SC;
        font-size: 12.48px;
        font-weight: 700;
      }
      .boder{
        background-color: #a30030;
        border-radius: 31.2px;
        bottom:-7.28px;
        height: 4.16px;
        width: 28.08px;
        margin-top: 5px;

        
        
      }
    }

    .picture {
      position: relative;
      .img {
        width: 335.91px;
        height: 87.36px;
        background-image: url(@/assets/img/最新公告.png);
        background-position: 50%;
        background-repeat: no-repeat;
        background-size: cover;
        border-radius: 4.16px;
        box-shadow: 0 3.12px 6.24px rgba(0, 0, 0, .16);
      }

      .listcontent {
        display: flex;
        flex-wrap: wrap;
        width: 310px;
        height: 43.36px;
        // background-color: #fff;
        margin-top: 9.32px;
        margin-left: 10px;
        

        .list{
          position: relative;
          display: flex;
          justify-content: flex-start;
          width: 280.8px;
          height: 16.63px;
          margin-bottom: 9.32px;

          .dot{
            position: absolute;
            display: block;
            background-color: black;
            width: 3px;
            height: 3px;
            border-radius: 50%;
            top:5px;
            left:-5px;

            
          }

          .text {
            font-size: 12.48px;
          }
        }
      }
      .more {
        position: absolute;
        width: 31.19px;
        height: 14.55px;
        background-color: #a30030;
        border-radius: 14.56px;
        font-size: 10.4px;
        color: #fff ;
        line-height: 14.55px;
        text-align: center;
        right: 15px;
        bottom: -20px;

      }
    }
  }
}
</style>

