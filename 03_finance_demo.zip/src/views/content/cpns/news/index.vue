<template>
  <div class=“news”>
    <div class="content">
      <div class="wrapper">
        <div class="title">
          <div class="both">
            <div class="titleinfo">招行新闻</div>
            <div class="subtitle">公司公告</div>
          </div>
          <div class="boder"></div>
        </div>
        <div class="listcontent">
          <div class="textcontent">
            <template v-for="item in messages" :key="item">
            <div class="list">
              <div class="dot"></div>
              <div class="text">{{ item }}</div>
            </div>
          </template>
          </div>
          <div class="more">更多</div> 
        </div>
      </div>
    </div>
  </div>
</template>


<script setup>

const messages = ["招商银行养老金融：发挥耐心资本优势，实现年金资产长期稳健增长","招商银行发行全市场首单“数智化转型”主题金融债","服务外贸企业更快捷 招行名录登记服务再升级","用好政策 打通堵点 招商银行积极助力城市房地产融资协调机制高效落地"]

</script>


<style lang="less" scoped>
.content {
  
  .wrapper{
    width:335.91px;
    height: 157.94px;
    // background-color: aqua;
    margin: 0 auto 26px;
    
    .title{
      // display: flex;
      height: 33.25px;
      margin-right: 8.32px;
      padding-left: 10px;
      .both {
        display: flex;
        .titleinfo{
          font-family: PingFang SC;
          font-size: 12.48px;
          font-weight: 700;
        }

        .subtitle {
          width: 49.92px;
          height: 16.63px;
          color: #717171;
          font-size: 12.48px;
          font-weight: 700;
          line-height: 16.63px;
          border-left: 1.5px solid rgb(189, 14, 14);
          margin-left: 3px;
          padding-left: 3px;
        }
      }
      .boder{
        background-color: #a30030;
        border-radius: 31.2px;
        bottom:-7.28px;
        height: 4.16px;
        width: 28.08px;
        margin-top: 5px;

        
        
      }
    }

    .listcontent {
      position: relative;
      // display: flex;
      // flex-wrap: wrap;
      width: 335.91px;
      height: 124.69px;
      background-color: #fff;
      border-radius: 15px;
      box-shadow: 3px 3px 8px  rgb(161, 161, 161);
      // padding: 3px 10px;
      .textcontent{
        position: absolute;
        width:335.91px ;
        height: 87.25px;
        // background-color: aquamarine;
        top: 10px;
        
        .list{
          width: 280.8px;
          height: 16.63px;
          position: relative;
          margin: 0 20px;
          margin-bottom: 3px;
          // background-color: #a30030;
          

          .dot{
            position: absolute;
            display: block;
            background-color: black;
            width: 3px;
            height: 3px;
            border-radius: 50%;
            top:8px;
            left:-5px;

            
          }

          .text {
            
            font-size: 12.48px;
            height: 16.63px;
            line-height: 16.63px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
          }
        }
      }

      .more {
        position: absolute;
        width: 31.19px;
        height: 14.55px;
        background-color: #a30030;
        border-radius: 14.56px;
        font-size: 10.4px;
        color: #fff;
        line-height: 14.55px;
        text-align: center;
        right: 15px;
        bottom: 15px;

      }
    }
  }

}
</style>

