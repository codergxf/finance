<template>
  <div class=“wipper”>
    <div class="wrapper content">
      <div class="wippercontent">
        <van-swipe :autoplay="3000" lazy-render>
          <van-swipe-item v-for="image in images" :key="image">
            <img :src="image" :style="{ width: '100%', height: '100%', objectFit: 'cover' ,'border-radius': '10px'}"/>
          </van-swipe-item>
        </van-swipe>
        <!-- <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
          <van-swipe-item>
            <img src="https://s3gw.cmbimg.com/lb50.01-cmbweb-prd/cmbcms/20240228/cbb29ffe-269c-4a34-b27f-63bca6052be2.jpg" alt="" :style="{ width: '100%', height: '100%', objectFit: 'cover' }">
          </van-swipe-item>
          <van-swipe-item>2</van-swipe-item>
          <van-swipe-item>3</van-swipe-item>
          <van-swipe-item>4</van-swipe-item>
        </van-swipe>
       -->
        
      </div>
    </div>
  </div>
</template>


<script setup>
const images = [
      'https://s3gw.cmbimg.com/lb50.01-cmbweb-prd/cmbcms/20240228/cbb29ffe-269c-4a34-b27f-63bca6052be2.jpg',
      'https://s3gw.cmbimg.com/lb50.01-cmbweb-prd/cmbcms/20240228/69b7e8b6-3e6a-424b-8d37-2378ae440812.jpg',
      'https://s3gw.cmbimg.com/lb50.01-cmbweb-prd/cmbcms/20240228/b2c05f48-6f51-4073-944e-4b31c3fbbced.jpg',
      'https://s3gw.cmbimg.com/lb50.01-cmbweb-prd/cmbcms/20240228/024470ac-3a55-4bff-a1ea-c52fe4f09493.jpg',
      'https://s3gw.cmbimg.com/lb50.01-cmbweb-prd/cmbcms/20240228/5272f846-2225-4fa0-ba4c-3de40b0e35db.jpg',
    ];

</script>


<style lang="less" scoped>
@import "@/assets/css/index.css";
.content {
  width: 390px;
  height: 177.84px;
  // background-color: rgb(12, 241, 165);
  
    .wippercontent {
      width: 338px;
      height: 156px;
      // background-color: aquamarine;
      margin: 0 auto;
      
      // .my-swipe {
      //   .van-swipe-item {
      //     color: #fff;
      //     font-size: 20px;
      //     line-height: 150px;
      //     text-align: center;
      //     background-color: #39a9ed;
      //   }
      // }
    
    
}
}
</style>

