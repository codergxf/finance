<template>
  <div class=“home”>
    <div class="textwrapper">
      <div class="title">关于近期贵金属业务市场风险提示的...</div>
    </div>
    <div class="content">
      
      <div class="bothitem">
        <!-- 循环列表 -->
        <div class="homecontent">
          <div class="img">
            <img src="@/assets/img/homeimg1.png" alt="">
          </div>
          <div class="textwrapper">
            <div class="text">招商银行App</div>
          </div>
        </div>

        <!-- 循环列表 -->
        <div class="homecontent">
          <div class="img">
            <img src="@/assets/img/homeimg2.png" alt="">
          </div>
          <div class="textwrapper">
            <div class="text">信用卡申请</div>
          </div>
        </div>

        <!-- 循环列表 -->
        <div class="homecontent">
          <div class="img">
            <img src="@/assets/img/homeimg3.png" alt="">
          </div>
          <div class="textwrapper">
            <div class="text">闪电贷</div>
          </div>
        </div>

        <!-- 循环列表 -->
        <div class="homecontent">
          <div class="img">
            <img src="@/assets/img/homeimg4.png" alt="">
          </div>
          <div class="textwrapper">
            <div class="text">商旅出行</div>
          </div>
        </div>

        <!-- 循环列表 -->
        <div class="homecontent">
          <div class="img">
            <img src="@/assets/img/homeimg5.png" alt="">
          </div>
          <div class="textwrapper">
            <div class="text">借记卡申请</div>
          </div>
        </div>

        <!-- 循环列表 -->
        <div class="homecontent">
          <div class="img">
            <img src="@/assets/img/homeimg6.png" alt="">
          </div>
          <div class="textwrapper">
            <div class="text">信用卡服务</div>
          </div>
        </div>

        <!-- 循环列表 -->
        <div class="homecontent">
          <div class="img">
            <img src="@/assets/img/homeimg7.png" alt="">
          </div>
          <div class="textwrapper">
            <div class="text">积分乐园</div>
          </div>
        </div>

        <!-- 循环列表 -->
        <div class="homecontent">
          <div class="img">
            <img src="@/assets/img/homeimg8.png" alt="">
          </div>
          <div class="textwrapper">
            <div class="text">理财计算器</div>
          </div>
        </div>

    

        
      </div>
    </div>
  </div>
</template>


<script setup>


</script>


<style lang="less" scoped>
.textwrapper{
  width: 335.91px;
  // background-color: rgb(247, 161, 214);
  margin: 0 auto;
  .title{
    width: 335.91px;
    height: 31.19px;
    background-color: #fff;
    font-size: 12.48px;
    font-weight: 700;
  }
}

.content {
  width: 335.91px;
  height: 158.02px;
  // background-color: rgb(247, 161, 214);
  margin: 0 auto 18.72px;
  border-radius: 15px;
  box-shadow: 3px 3px 8px  rgb(161, 161, 161);
 

  .bothitem {
    padding: 5.2px 5.2px 3.12px;
    display: flex;
    flex-wrap: wrap;
    .homecontent{
      width: 81.38px;
      height: 74.86px;
      padding: 9.36px 0;
      box-sizing: border-box;
      // background-color: aquamarine;

      img{
        display: block;
        width: 37.44px;
        height: 37.44px;
        margin: 0 auto;
      }
      .textwrapper{
        width: 81.38px;
        height: 16.64px;
        background-color: #fff;
        margin-top: 2.08px;
        box-sizing: border-box;
        .text {
          
          color: #171717;
          font-family: PingFang SC;
          font-size: 12.48px;
          font-weight: 500;
          height: 16.64px;
          line-height: 16.63px;
          
          text-align: center;
          
      }
      }
      
    }
  }
  

}
</style>

