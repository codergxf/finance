<template>
  <div class=“footer”>
    <div class="content">
      <div class="bothitems">
        <!-- <template v-for="(item,index) in footerData" :key="item.id"> -->
          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer1.png" alt="">
              
            </div>
            <div class="text">服务热线</div>
          </div>

          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer2.png" alt="">
              
            </div>
            <div class="text">网站声明</div>
          </div>

          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer3.png" alt="">
              
            </div>
            <div class="text">返回顶部</div>
          </div>

          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer4.png" alt="">
              
            </div>
            <div class="text">服务价格</div>
          </div>

          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer5.png" alt="">
              
            </div>
            <div class="text">客户投诉指南</div>
          </div>

          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer6.png" alt="">
              
            </div>
            <div class="text">消费者权益保护</div>
          </div>

          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer7.png" alt="">
              
            </div>
            <div class="text">友情链接</div>
          </div>

          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer8.png" alt="">
              
            </div>
            <div class="text">隐私条款</div>
          </div>

          <!-- 列表 -->
          <div class="footer-item">
            <div class="img">
              <img src="@/assets/img/footer9.png" alt="">
              
            </div>
            <div class="text">电脑版</div>
          </div>
          
        <!-- </template>  -->
      </div>
      <div class="footerinfo">
        <div class="info">CopyRight© 1997-2023 招商银行一网通版权所有</div>
        <div class="info">粤ICP备17088997号</div>
        <div class="info">本网站支持IPv6</div>
      </div>
    </div>
  </div>
</template>


<script setup>
// import useFinanceMessage from "@/stores/modules/financeMessage.js";
// import {computed} from 'vue'
// import { storeToRefs } from 'pinia'

// const financeMessageStore = useFinanceMessage()
// const {footerData} = storeToRefs(financeMessageStore)

//定义数据
// const imgUrl = relative(["@/assets/img/footer1.png"],["@/assets/img/footer2.png"])
</script>


<style lang="less" scoped>
.content {
  // background-color: aquamarine;
  height: 354.94px;
  // position: relative;
  padding-top: 10px;
  box-sizing: border-box;

  .bothitems{
    display: flex;
    flex-wrap: wrap;
    width: 346.31px;
    height: 187.5px;
    // background-color: aqua;
    margin: 0 auto;
    

    .footer-item {
      // background-color:bisque ;
      width: 115.42px;
      height: 52.11px;
      margin-bottom: 10.4px;
      color: #171717;
      font-size: 12.48px;
      font-weight: 500;
      
      img {
        display: block;
        width: 33.27px;
        margin: 0 auto;
      }

      .text{
        // display: inline-block;
        margin: 0 auto;
        text-align: center;
      }
      
    }

    
  }


  .footerinfo {
      color: rgb(101, 101, 101);
      font-family: "PingFang SC";
      font-size: 12.48px;
      font-weight: 500;
      line-height: 16.64px;
      padding-bottom: 78px;
      text-align: center;
    }
  
}
</style>

