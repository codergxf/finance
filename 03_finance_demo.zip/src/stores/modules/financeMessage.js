import { defineStore } from "pinia";

const useFinanceMessage = defineStore("financeMessage",{
  state: () => ({
    financeMessage:["存款利率","贷款利率","外汇实时汇率","黄金市场行情","个人理财产品净值","公司理财产品净值","离岸业务存款利率","招商股价","储蓄国债"],
    homeData:["招商银行App","信用卡申请","闪电贷","商旅出行","借记卡申请","信用卡服务","积分乐园","理财计算器"],
    newNotice:["关于调整人民币存款利率的公告","关于调整黄金账户认购起点金额及风险提示的通告"],
    news:["招商银行养老金融：发挥耐心资本优势，实现年金资产长期稳健增长","招商银行发行全市场首单“数智化转型”主题金融债","服务外贸企业更快捷 招行名录登记服务再升级","用好政策 打通堵点 招商银行积极助力城市房地产融资协调机制高效落地"],
    product:["兴银理财富利兴成稳健六个月持有期3号混合类理财产品","招银理财招睿鑫远生金日开360天持有1号固收增强理财计划","浦银理财悦臻封闭式19号（私募尊享）","兴银理财丰利悦动封闭式48号固收类理财产品"],
    footerData:[{
      id:1,
      text:"服务热线",
      img: "@/assets/img/footer1.png"
    },
    {
      id:2,
      text:"网站声明",
      img: new URL("@assets/img/footer2",import.meta.url).href
    },
    {
      id:3,
      text:"返回顶部",
      img: new URL("@assets/img/footer3",import.meta.url).href
    },
    {
      id:4,
      text:"服务价格",
      img: new URL("@assets/img/footer4",import.meta.url).href
    },
    {
      id:5,
      text:"客户投诉指南",
      img: new URL("@assets/img/footer5",import.meta.url).href
    },
    {
      id:6,
      text:"消费者权益保护",
      img: new URL("@assets/img/footer6",import.meta.url).href
    },
    {
      id:7,
      text:"友情链接",
      img: new URL("@assets/img/footer7",import.meta.url).href
    },
    {
      id:8,
      text:"隐私条款",
      img: new URL("@assets/img/footer8",import.meta.url).href
    },
    {
      id:9,
      text:"电脑版",
      img: new URL("@assets/img/footer9",import.meta.url).href
    }
  ],
    wrapperImage: [{
      index:1,
      img: new URL("@assets/img/image1",import.meta.url).href
    },
    {
      index:2,
      img: new URL("@assets/img/image2",import.meta.url).href
    },{
      index:3,
      img: new URL("@assets/img/image3",import.meta.url).href
    },{
      index:4,
      img: new URL("@assets/img/image4",import.meta.url).href
    },
    {
      index:5,
      img: new URL("@assets/img/image5",import.meta.url).href
    },
  ],

  homeImage:[{
    index:1,
    img: new URL("@assets/img/homeimg1",import.meta.url).href
  },
  {
    index:2,
    img: new URL("@assets/img/homeimg2",import.meta.url).href
  },
  {
    index:3,
    img: new URL("@assets/img/homeimg3",import.meta.url).href
  },
  {
    index:4,
    img: new URL("@assets/img/homeimg4",import.meta.url).href
  },
  {
    index:5,
    img: new URL("@assets/img/homeimg5",import.meta.url).href
  },
  {
    index:6,
    img: new URL("@assets/img/homeimg6",import.meta.url).href
  },
  {
    index:7,
    img: new URL("@assets/img/homeimg7",import.meta.url).href
  },
  {
    index:8,
    img: new URL("@assets/img/homeimg8",import.meta.url).href
  },
]
  }),

  getters: {
    getImageUrl: (state) => {
      
      return state.homeImage.img
      
    }
  }
})

export default useFinanceMessage