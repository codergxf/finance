<template>
  <div class=“app”>
    <!-- <main></main> -->
    <router-view></router-view>
  </div>
</template>


<script setup>
// import Main from "@/views/main/index.vue"

</script>


<style lang="less" scoped>


</style>

