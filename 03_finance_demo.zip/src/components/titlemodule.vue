<template>
  <div class=“titlemodule”>
    <div class="content">
      <div class="wrapper">
        <!-- 标题 -->
        <div class="title">
          <div class="titleinfo">{{ title }}</div>
          <div class="boder"></div>
        </div>
      </div>
    </div>
  </div>
</template>


<script setup>
defineProps({
  title:{
    type: String,
    default: "我是默认值"

  }
})

</script>


<style lang="less" scoped>
.content {
  
  .wrapper{
    width:335.91px;
    height: 218.36px;
    // background-color: aqua;
    margin: 0 auto 26px;
    
    .title{
      
      height: 33.25px;
      margin-right: 8.32px;
      padding-left: 10px;
      
      .titleinfo{
        font-family: PingFang SC;
        font-size: 12.48px;
        font-weight: 700;
      }
      .boder{
        background-color: #a30030;
        border-radius: 31.2px;
        bottom:-7.28px;
        height: 4.16px;
        width: 28.08px;
        margin-top: 5px;

        
        
      }
    }
  }
}
</style>

